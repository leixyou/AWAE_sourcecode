<?php
/************************************************************************/
/* ATutor																*/
/************************************************************************/
/* Copyright (c) 2002-2010                                              */
/* http://atutor.ca                                                     */
/* This program is free software. You can redistribute it and/or        */
/* modify it under the terms of the GNU General Public License          */
/* as published by the Free Software Foundation.                        */
/************************************************************************/

// $Id$

/* If this file is from the trunk, it is *supposed* to have comments only. */
/* http://atutor.ca/atutor/mantis/view.php?id=4669 */

/* created by the bundle script.                     */
/* the resulting file will look something like this: */
/* $svn_data = '
------------------------------------------------------------------------
r3125 | joel | 2005-01-21 16:27:14 -0500 (Fri, 21 Jan 2005)
------------------------------------------------------------------------';
*/
?><?php $svn_data = 'Thu Mar 21 09:55:11 UTC 2013
';?>
