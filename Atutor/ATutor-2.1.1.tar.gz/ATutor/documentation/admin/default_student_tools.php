<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Default Course Tools</h2>

	<p>Administrators are able to set the tools that will appear in the main navigation and the home page for newly created courses by specifying student tool defaults. Instructors can alter these settings after a course is created by going to <a href="../instructor/student_tools.php">Course Tools</a> area  under the Manage tab.</p>

<?php require('../common/body_footer.inc.php'); ?>