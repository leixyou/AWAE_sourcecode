<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Google Key</h2>

	<p>For the Web Search module to function, an administrator must first create an account and obtain a license key at <a href="http://google.com/apis" target="_new">google.com/apis</a> and enter it on this page. The google web search can then be used by students as an external embedded service within ATutor.</p>

<?php require('../common/body_footer.inc.php'); ?>