<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-07-01 18:04:33 -0400 (Sat, 01 Jul 2006) $'; ?>

<h2>Photo</h2>

<p>This page display a photo and its description.  You can click the "Previous" and "Next" arrows to move through the photos in the album you are viewing.  Owners of a photo can also edit the description by simply clicking on the description itself, or via the "Edit Photo" link.  </p>

<p>Also view <strong>Comments</strong> for details on posting comments. </p>

<?php require('../common/body_footer.inc.php'); ?>
