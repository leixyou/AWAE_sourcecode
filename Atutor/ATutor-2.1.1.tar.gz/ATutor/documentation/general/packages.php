<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Packages</h2>

<p>If instructors have included SCORM compliant Sharable Content Objects (SCOs), they will be avilable for viewing using the <em>Packages</em> tool. Note that the SCORM Run Time Environment (RTE) requires the Java JRE 1.5 to function properly, as well as LiveConnect, which is enabled by default in the JRE 1.5. Download an install with <a href="http://java.sun.com/javase/downloads/index.jsp" target="new">latest Java JRE</a> from the SUN site, if you need to upgrade your browser's java support.</p>

<?php require('../common/body_footer.inc.php'); ?>