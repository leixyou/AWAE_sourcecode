<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Web Search</h2>
	<p>Since version 1.5.2, course members can use Google to search the web from within an ATutor course.</p>

	<p>The Web Search is a <a href="student_tools.php">Course Tool</a> and can therefore be enabled or disabled, linked from the main menu, linked from the home page, or displayed as a side menu box.</p>

<?php require('../common/body_footer.inc.php'); ?>
