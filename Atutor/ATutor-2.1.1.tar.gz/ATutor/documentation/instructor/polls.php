<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Polls</h2>
	<p>Polls are useful for quickly gathering course member opinions. Instructors and students with poll privileges can post a question with up to seven choices for answers. Unlike <a href="tests_surveys.php">Tests and Surveys</a>, Polls are not graded. Because Polls is a <a href="student_tools.php">Course Tool</a>, it can be enabled, disabled, and positioned according to the Course Tools preferences. </p>

<?php require('../common/body_footer.inc.php'); ?>