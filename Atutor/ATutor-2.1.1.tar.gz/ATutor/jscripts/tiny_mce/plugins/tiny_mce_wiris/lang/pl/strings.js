var strings = new Array();
strings['cancel'] = 'Anuluj';
strings['accept'] = 'OK';
strings['manual'] = 'Instrukcja';
strings['latex'] = 'LaTeX';