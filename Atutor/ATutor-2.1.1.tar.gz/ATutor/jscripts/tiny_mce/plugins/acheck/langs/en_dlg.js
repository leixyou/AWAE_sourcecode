tinyMCE.addI18n('en.acheck_dlg',{
	title : 'ATRC Accessibility Checker'
});
