tinyMCE.addI18n('en.acheck',{
	desc : 'Check Accessibility'
});
